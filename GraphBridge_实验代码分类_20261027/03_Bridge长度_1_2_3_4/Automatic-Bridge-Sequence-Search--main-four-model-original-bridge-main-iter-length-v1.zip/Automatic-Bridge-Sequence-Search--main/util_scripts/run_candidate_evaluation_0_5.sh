#!/usr/bin/env bash
set -euo pipefail

MODELS="${MODELS:-QWEN_PLUS_NON_THINKING}"
SUITES="${SUITES:-banking slack travel workspace}"
LOG_ROOT="${LOG_ROOT:-runs/max_evaluations_5}"
BRIDGE_BUDGET="${BRIDGE_BUDGET:-2}"
MAX_EVALUATIONS="${MAX_EVALUATIONS:-5}"
DEFENSE="${DEFENSE:-}"
FORCE_RERUN="${FORCE_RERUN:-0}"

for model in $MODELS
do
  for suite in $SUITES
  do
    model_dir="$(echo "$model" | tr '[:upper:]' '[:lower:]' | tr '_' '-')"
    summary="$LOG_ROOT/$model_dir/$suite/_bridge-realizer/summary.json"
    if [ "$FORCE_RERUN" != "1" ] && [ -f "$summary" ]; then
      echo "SKIP existing model=$model suite=$suite summary=$summary"
      continue
    fi

    echo "RUN candidate sensitivity model=$model suite=$suite bridge_budget=$BRIDGE_BUDGET max_evaluations=$MAX_EVALUATIONS defense=${DEFENSE:-none} at $(date)"
    cmd=(
      python -m agentdojo.scripts.adaptive_benchmark
      --model "$model"
      --suite "$suite"
      --logdir "$LOG_ROOT"
      --bridge-budget "$BRIDGE_BUDGET"
      --max-evaluations "$MAX_EVALUATIONS"
    )
    if [ -n "$DEFENSE" ]; then
      cmd+=(--defense "$DEFENSE")
    fi
    if [ "$FORCE_RERUN" = "1" ]; then
      cmd+=(--force-rerun)
    fi
    "${cmd[@]}"
  done
done
