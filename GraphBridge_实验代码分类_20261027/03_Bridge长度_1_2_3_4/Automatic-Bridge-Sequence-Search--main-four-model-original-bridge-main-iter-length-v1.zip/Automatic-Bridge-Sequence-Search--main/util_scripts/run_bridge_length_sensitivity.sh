#!/usr/bin/env bash
set -euo pipefail

MODELS="${MODELS:-DEEPSEEK_V4_FLASH_THINKING DEEPSEEK_V4_FLASH_NON_THINKING QWEN_PLUS_THINKING QWEN_PLUS_NON_THINKING}"
SUITES="${SUITES:-banking slack travel workspace}"
BUDGETS="${BUDGETS:-1 2 3 4}"
LOG_ROOT_PREFIX="${LOG_ROOT_PREFIX:-runs/bridge_budget}"
MAX_EVALUATIONS="${MAX_EVALUATIONS:-3}"
DEFENSE="${DEFENSE:-}"
FORCE_RERUN="${FORCE_RERUN:-0}"

for k in $BUDGETS
do
  log_root="${LOG_ROOT_PREFIX}_${k}"
  for model in $MODELS
  do
    for suite in $SUITES
    do
      model_dir="$(echo "$model" | tr '[:upper:]' '[:lower:]' | tr '_' '-')"
      summary="$log_root/$model_dir/$suite/_bridge-realizer/summary.json"
      if [ "$FORCE_RERUN" != "1" ] && [ -f "$summary" ]; then
        echo "SKIP existing budget=$k model=$model suite=$suite summary=$summary"
        continue
      fi

      echo "RUN model=$model suite=$suite bridge_budget=$k max_evaluations=$MAX_EVALUATIONS defense=${DEFENSE:-none} at $(date)"
      cmd=(
        python -m agentdojo.scripts.adaptive_benchmark
        --model "$model"
        --suite "$suite"
        --logdir "$log_root"
        --bridge-budget "$k"
        --max-evaluations "$MAX_EVALUATIONS"
      )
      if [ -n "$DEFENSE" ]; then
        cmd+=(--defense "$DEFENSE")
      fi
      if [ "$FORCE_RERUN" = "1" ]; then
        cmd+=(--force-rerun)
      fi
      "${cmd[@]}"
    done
  done
done
