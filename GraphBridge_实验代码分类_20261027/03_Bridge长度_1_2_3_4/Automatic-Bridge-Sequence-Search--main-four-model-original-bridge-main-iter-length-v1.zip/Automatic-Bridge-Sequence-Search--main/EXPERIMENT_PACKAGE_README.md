# Four-model original GraphBridge package

Purpose:
- Main GraphBridge experiments.
- Bridge length sensitivity.
- Candidate evaluation sensitivity from candidate 1 to 5.

This package keeps the original GraphBridge payload construction path. It does not use the later template-generalization variants. The only compatibility change is that `--bridge-budget` accepts values from 0 to 5.

Registered models:
- `DEEPSEEK_V4_FLASH_THINKING`
- `DEEPSEEK_V4_FLASH_NON_THINKING`
- `QWEN_PLUS_THINKING`
- `QWEN_PLUS_NON_THINKING`

Useful scripts:
- `util_scripts/run_four_models_bridge_main.sh`
- `util_scripts/run_bridge_length_sensitivity.sh`
- `util_scripts/run_candidate_evaluation_0_5.sh`

Before running:
```bash
cd /root/autodl-tmp/Automatic-Bridge-Sequence-Search--main
export PYTHONPATH=src
```

Main experiment example:
```bash
MODELS="QWEN_PLUS_NON_THINKING" \
SUITES="banking slack travel workspace" \
LOG_ROOT="runs/main_bridge" \
bash util_scripts/run_four_models_bridge_main.sh
```

Candidate-evaluation experiment example:
```bash
MODELS="QWEN_PLUS_NON_THINKING" \
SUITES="banking slack travel workspace" \
LOG_ROOT="runs/max_evaluations_5" \
bash util_scripts/run_candidate_evaluation_0_5.sh
```

Bridge-length experiment example:
```bash
MODELS="QWEN_PLUS_NON_THINKING" \
BUDGETS="1 2 3 4" \
SUITES="banking slack travel workspace" \
bash util_scripts/run_bridge_length_sensitivity.sh
```
