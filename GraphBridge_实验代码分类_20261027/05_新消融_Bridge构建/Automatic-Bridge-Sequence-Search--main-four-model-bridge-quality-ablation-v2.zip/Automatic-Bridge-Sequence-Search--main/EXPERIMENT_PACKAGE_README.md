# Four-model bridge quality ablation package

Purpose:
- Bridge construction ablation:
  - `no_bridge`
  - `random_bridge`
  - `graphbridge`

This package registers the four project models and keeps the original GraphBridge payload construction path for the `graphbridge` condition. `random_bridge` deterministically replaces the selected bridge with a same-length bridge sampled from unrelated pairs in the same suite, and `no_bridge` removes the bridge.

Registered models:
- `DEEPSEEK_V4_FLASH_THINKING`
- `DEEPSEEK_V4_FLASH_NON_THINKING`
- `QWEN_PLUS_THINKING`
- `QWEN_PLUS_NON_THINKING`

Example:
```bash
cd /root/autodl-tmp/Automatic-Bridge-Sequence-Search--main
export PYTHONPATH=src

MODELS="QWEN_PLUS_NON_THINKING" \
SUITES="banking slack travel workspace" \
VARIANTS="no_bridge random_bridge graphbridge" \
LOG_ROOT="runs/bridge_quality_ablation" \
bash util_scripts/run_bridge_quality_ablation_full.sh
```
