# Bridge Construction Ablation Patch

This package adds a small ablation switch for testing whether GraphBridge's
constructed bridge is better than control bridge variants.

## What changed

- Added four model aliases:
  - `DEEPSEEK_V4_FLASH_THINKING`
  - `DEEPSEEK_V4_FLASH_NON_THINKING`
  - `QWEN_PLUS_THINKING`
  - `QWEN_PLUS_NON_THINKING`
- Added DashScope and DeepSeek OpenAI-compatible providers.
- Added `--bridge-control` to `agentdojo.scripts.adaptive_benchmark`:
  - `graphbridge`: original GraphBridge behavior.
  - `random_bridge`: replaces the selected bridge with a deterministic bridge of the same length sampled from other pairs in the same suite.
  - `no_bridge`: removes the bridge and evaluates the malicious core directly in the same injection slot.
- Added `--random-seed` for deterministic `random_bridge`.
- Added `util_scripts/run_bridge_quality_ablation.sh`.

## What did not change

- The GraphBridge payload template was not rewritten.
- The malicious goal is not modified.
- The bridge scoring logic is not modified.
- The evaluator is not modified.

## Example

```bash
cd /root/autodl-tmp/Automatic-Bridge-Sequence-Search--main
export PYTHONPATH=src

mkdir -p runs/logs

nohup bash -c '
MODELS="DEEPSEEK_V4_FLASH_NON_THINKING QWEN_PLUS_NON_THINKING" \
SUITES="banking slack" \
VARIANTS="no_bridge random_bridge graphbridge" \
LOG_ROOT="runs/bridge_quality_ablation" \
FORCE_RERUN=0 \
bash util_scripts/run_bridge_quality_ablation.sh
' > runs/logs/bridge_quality_ablation.out 2>&1 &

echo $! > runs/logs/bridge_quality_ablation.pid
tail -f runs/logs/bridge_quality_ablation.out
```
