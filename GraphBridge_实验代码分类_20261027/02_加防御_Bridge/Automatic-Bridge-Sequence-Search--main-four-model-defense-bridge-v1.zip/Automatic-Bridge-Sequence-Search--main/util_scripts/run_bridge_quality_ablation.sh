#!/usr/bin/env bash
set -euo pipefail

MODELS="${MODELS:-DEEPSEEK_V4_FLASH_NON_THINKING QWEN_PLUS_NON_THINKING}"
SUITES="${SUITES:-banking slack}"
VARIANTS="${VARIANTS:-no_bridge random_bridge graphbridge}"
LOG_ROOT="${LOG_ROOT:-runs/bridge_quality_ablation}"
BRIDGE_BUDGET="${BRIDGE_BUDGET:-2}"
MAX_EVALUATIONS="${MAX_EVALUATIONS:-3}"
RANDOM_SEED="${RANDOM_SEED:-0}"
FORCE_RERUN="${FORCE_RERUN:-0}"

for variant in $VARIANTS
do
  for model in $MODELS
  do
    for suite in $SUITES
    do
      logdir="$LOG_ROOT/$variant"
      summary="$logdir/$(echo "$model" | tr '[:upper:]' '[:lower:]' | tr '_' '-')/$suite/_bridge-realizer/summary.json"
      if [ "$variant" != "graphbridge" ]; then
        summary="$logdir/$(echo "$model" | tr '[:upper:]' '[:lower:]' | tr '_' '-')/$suite/_bridge-realizer-$variant/summary.json"
      fi

      if [ "$FORCE_RERUN" != "1" ] && [ -f "$summary" ]; then
        echo "SKIP existing variant=$variant model=$model suite=$suite summary=$summary"
        continue
      fi

      echo "RUN variant=$variant model=$model suite=$suite at $(date)"
      cmd=(
        python -m agentdojo.scripts.adaptive_benchmark
        --model "$model"
        --suite "$suite"
        --logdir "$logdir"
        --bridge-control "$variant"
        --bridge-budget "$BRIDGE_BUDGET"
        --max-evaluations "$MAX_EVALUATIONS"
        --random-seed "$RANDOM_SEED"
      )
      if [ "$FORCE_RERUN" = "1" ]; then
        cmd+=(--force-rerun)
      fi
      "${cmd[@]}"
    done
  done
done
