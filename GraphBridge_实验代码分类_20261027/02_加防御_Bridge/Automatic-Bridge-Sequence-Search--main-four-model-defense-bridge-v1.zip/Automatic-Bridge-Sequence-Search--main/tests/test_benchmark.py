import json
from pathlib import Path

from agentdojo.benchmark import convert_old_messages_format
from agentdojo.scripts.benchmark import (
    build_suite_summary,
    get_benchmark_summary_filename,
    save_suite_summary,
)


def test_convert_old_messages_format():
    # Test with various message types
    old_messages = [
        {"role": "user", "content": "Hello"},
        {"role": "assistant", "content": "Hi there", "tool_calls": None},
        {
            "role": "tool",
            "content": "123",
            "tool_call": {"function": "add", "args": {"a": 1, "b": 2}},
            "tool_call_id": None,
            "error": None,
        },
        {"role": "system", "content": "You are a helpful assistant"},
        {"role": "assistant", "content": None, "tool_calls": [{"function": "multiply", "args": {"a": 3, "b": 4}}]},
    ]

    converted = convert_old_messages_format(old_messages)

    # Check that each message was properly converted
    assert len(converted) == 5

    # User message
    assert converted[0]["role"] == "user"
    assert len(converted[0]["content"]) == 1
    assert converted[0]["content"][0]["type"] == "text"
    assert converted[0]["content"][0]["content"] == "Hello"

    # Assistant message with content
    assert converted[1]["role"] == "assistant"
    assert converted[1]["content"] is not None
    assert len(converted[1]["content"]) == 1
    assert converted[1]["content"][0]["type"] == "text"
    assert converted[1]["content"][0]["content"] == "Hi there"
    assert converted[1]["tool_calls"] is None

    # Tool message
    assert converted[2]["role"] == "tool"
    assert len(converted[2]["content"]) == 1
    assert converted[2]["content"][0]["type"] == "text"
    assert converted[2]["content"][0]["content"] == "123"
    assert converted[2]["tool_call"]["function"] == "add"

    # System message
    assert converted[3]["role"] == "system"
    assert len(converted[3]["content"]) == 1
    assert converted[3]["content"][0]["type"] == "text"
    assert converted[3]["content"][0]["content"] == "You are a helpful assistant"

    # Assistant message with tool calls but no content
    assert converted[4]["role"] == "assistant"
    assert converted[4]["content"] is None
    assert converted[4]["tool_calls"] is not None

    # Check that original messages are not modified
    assert isinstance(old_messages[0]["content"], str)

    # Check return type is list[ChatMessage]
    assert isinstance(converted, list)
    for message in converted:
        assert isinstance(message, dict)


def test_build_suite_summary_with_attack_metrics():
    results = {
        "utility_results": {("user_task_1", "injection_task_0"): True, ("user_task_1", "injection_task_1"): False},
        "security_results": {("user_task_1", "injection_task_0"): False, ("user_task_1", "injection_task_1"): True},
        "injection_tasks_utility_results": {"injection_task_0": True, "injection_task_1": False},
    }

    summary = build_suite_summary(
        suite_name="workspace",
        pipeline_name="gpt-4o-2024-05-13",
        attack_name="tool_knowledge",
        benchmark_version="v1.2.2",
        user_tasks=("user_task_1",),
        injection_tasks=(),
        results=results,
    )

    assert summary.average_utility == 0.5
    assert summary.average_security == 0.5
    assert summary.passed_injection_tasks == 1
    assert summary.total_injection_tasks == 2
    assert summary.utility_results[0].user_task_id == "user_task_1"
    assert summary.utility_results[0].injection_task_id == "injection_task_0"


def test_save_suite_summary_uses_attack_and_user_task_in_filename(tmp_path):
    results = {
        "utility_results": {("user_task_1", "injection_task_0"): True},
        "security_results": {("user_task_1", "injection_task_0"): False},
        "injection_tasks_utility_results": {"injection_task_0": True},
    }
    summary = build_suite_summary(
        suite_name="workspace",
        pipeline_name="gpt-4o-2024-05-13",
        attack_name="tool_knowledge",
        benchmark_version="v1.2.2",
        user_tasks=("user_task_1",),
        injection_tasks=("injection_task_0",),
        results=results,
    )

    output_path = save_suite_summary(summary, Path(tmp_path), ("user_task_1",), ("injection_task_0",))

    assert output_path.name == get_benchmark_summary_filename(
        "tool_knowledge", ("user_task_1",), ("injection_task_0",)
    )
    payload = json.loads(output_path.read_text(encoding="utf-8"))
    assert payload["attack_name"] == "tool_knowledge"
    assert payload["average_utility"] == 1.0
