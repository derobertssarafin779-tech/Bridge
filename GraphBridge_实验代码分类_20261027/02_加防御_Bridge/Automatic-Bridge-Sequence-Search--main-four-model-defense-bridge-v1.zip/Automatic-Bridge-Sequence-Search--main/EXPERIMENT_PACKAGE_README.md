# Four-model defended GraphBridge package

Purpose:
- GraphBridge experiments under defense, especially `spotlighting_with_delimiting`.

This package registers the four project models and keeps the original GraphBridge payload construction path. It supports `--defense` through `agentdojo.scripts.adaptive_benchmark`.

Registered models:
- `DEEPSEEK_V4_FLASH_THINKING`
- `DEEPSEEK_V4_FLASH_NON_THINKING`
- `QWEN_PLUS_THINKING`
- `QWEN_PLUS_NON_THINKING`

Default script:
```bash
cd /root/autodl-tmp/Automatic-Bridge-Sequence-Search--main
export PYTHONPATH=src

MODELS="QWEN_PLUS_NON_THINKING" \
SUITES="banking slack travel workspace" \
DEFENSE="spotlighting_with_delimiting" \
LOG_ROOT="runs/bridge_defense_spotlighting" \
bash util_scripts/run_four_models_bridge_defense.sh
```
