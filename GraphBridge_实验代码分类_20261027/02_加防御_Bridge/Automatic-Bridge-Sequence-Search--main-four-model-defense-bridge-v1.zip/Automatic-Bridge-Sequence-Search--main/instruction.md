python -m agentdojo.scripts.adaptive_benchmark \
  --suite banking \
  --model GPT_4O_2024_05_13 \
  --user-task user_task_0 \
  --defense tool_filter \
  --max-length 3 \
  --beam-width 5 \
  --max-candidates 6 \
  --alpha 0.5 \
  --beta 0.5


python -m agentdojo.scripts.benchmark \
-s banking \
-ut user_task_0 \
--model GPT_4O_2024_05_13 \
--attack important_instructions

