import importlib
import json
import logging
import warnings
from dataclasses import asdict, dataclass
from itertools import repeat
from multiprocessing import Pool
from pathlib import Path
from typing import Literal

import click
from dotenv import load_dotenv
from rich import print
from rich.live import Live
from rich.logging import RichHandler

from agentdojo.agent_pipeline.agent_pipeline import DEFENSES, AgentPipeline, PipelineConfig
from agentdojo.attacks.attack_registry import ATTACKS, load_attack
from agentdojo.benchmark import SuiteResults, benchmark_suite_with_injections, benchmark_suite_without_injections
from agentdojo.logging import OutputLogger
from agentdojo.models import ModelsEnum
from agentdojo.task_suite.load_suites import get_suite, get_suites
from agentdojo.task_suite.task_suite import TaskSuite


@dataclass(frozen=True)
class BenchmarkTaskResultSummary:
    user_task_id: str
    injection_task_id: str | None
    passed: bool


@dataclass
class SuiteBenchmarkSummary:
    suite_name: str
    pipeline_name: str
    attack_name: str | None
    average_utility: float
    average_security: float | None
    passed_injection_tasks: int | None
    total_injection_tasks: int | None
    config: dict[str, str | int | bool | None | list[str]]
    utility_results: list[BenchmarkTaskResultSummary]
    security_results: list[BenchmarkTaskResultSummary]
    injection_tasks_utility_results: dict[str, bool]


def summarize_task_results(results: dict[tuple[str, str], bool]) -> list[BenchmarkTaskResultSummary]:
    return [
        BenchmarkTaskResultSummary(user_task_id=user_task_id, injection_task_id=injection_task_id or None, passed=passed)
        for (user_task_id, injection_task_id), passed in sorted(results.items())
    ]


def build_suite_summary(
    suite_name: str,
    pipeline_name: str,
    attack_name: str | None,
    benchmark_version: str,
    user_tasks: tuple[str, ...],
    injection_tasks: tuple[str, ...],
    results: SuiteResults,
) -> SuiteBenchmarkSummary:
    utility_results = results["utility_results"]
    average_utility = sum(utility_results.values()) / len(utility_results) if len(utility_results) > 0 else 0.0

    security_results = results["security_results"]
    average_security = None
    if attack_name is not None and len(security_results) > 0:
        average_security = sum(security_results.values()) / len(security_results)

    injection_tasks_utility_results = results["injection_tasks_utility_results"]
    passed_injection_tasks = None
    total_injection_tasks = None
    if attack_name is not None:
        passed_injection_tasks = sum(injection_tasks_utility_results.values())
        total_injection_tasks = len(injection_tasks_utility_results)

    return SuiteBenchmarkSummary(
        suite_name=suite_name,
        pipeline_name=pipeline_name,
        attack_name=attack_name,
        average_utility=average_utility,
        average_security=average_security,
        passed_injection_tasks=passed_injection_tasks,
        total_injection_tasks=total_injection_tasks,
        config={
            "benchmark_version": benchmark_version,
            "attack": attack_name,
            "user_tasks": list(user_tasks),
            "injection_tasks": list(injection_tasks),
        },
        utility_results=summarize_task_results(utility_results),
        security_results=summarize_task_results(security_results),
        injection_tasks_utility_results=injection_tasks_utility_results,
    )


def get_benchmark_summary_filename(
    attack_name: str | None,
    user_tasks: tuple[str, ...],
    injection_tasks: tuple[str, ...],
) -> str:
    name_parts = ["summary", attack_name or "none"]
    if len(user_tasks) == 1:
        name_parts.append(user_tasks[0])
    if len(injection_tasks) == 1:
        name_parts.append(injection_tasks[0])
    return "__".join(name_parts) + ".json"


def save_suite_summary(
    summary: SuiteBenchmarkSummary,
    logdir: Path,
    user_tasks: tuple[str, ...],
    injection_tasks: tuple[str, ...],
) -> Path:
    output_dir = logdir / summary.pipeline_name.replace("/", "_") / summary.suite_name / "_benchmark"
    output_dir.mkdir(parents=True, exist_ok=True)
    output_path = output_dir / get_benchmark_summary_filename(summary.attack_name, user_tasks, injection_tasks)
    output_path.write_text(json.dumps(asdict(summary), indent=2), encoding="utf-8")
    return output_path


def benchmark_suite(
    suite: TaskSuite,
    model: ModelsEnum,
    logdir: Path,
    force_rerun: bool,
    benchmark_version: str,
    user_tasks: tuple[str, ...] = (),
    injection_tasks: tuple[str, ...] = (),
    model_id: str | None = None,
    attack: str | None = None,
    defense: str | None = None,
    tool_delimiter: str = "tool",
    system_message_name: str | None = None,
    system_message: str | None = None,
    live: Live | None = None,
    tool_output_format: Literal["yaml", "json"] | None = None,
) -> SuiteResults:
    # 入口脚本只尝试从当前工作目录加载 .env；
    # 若用户从别的目录启动，需要显式 export 环境变量或切到仓库根目录运行。
    if not load_dotenv(".env"):
        warnings.warn("No .env file found")

    # 这里打印的是本次实验的高层配置，便于在终端日志里快速确认参数是否正确。
    print(f"Running benchmark for suite: '{suite.name}'")
    print(f"Using model: '{model}'")
    if attack is not None:
        print(f"Using attack: '{attack}'")
    if defense is not None:
        print(f"Using defense: '{defense}'")
    if len(user_tasks) > 0:
        print(f"Using user tasks: {', '.join(user_tasks)}")

    # AgentPipeline.from_config 会在内部完成：
    # 1. provider / model 客户端初始化
    # 2. defense 装配
    # 3. 工具执行循环拼接
    pipeline = AgentPipeline.from_config(
        PipelineConfig(
            llm=model,
            model_id=model_id,
            defense=defense,
            tool_delimiter=tool_delimiter,
            system_message_name=system_message_name,
            system_message=system_message,
            tool_output_format=tool_output_format,
        )
    )
    with OutputLogger(str(logdir), live=live):
        if attack is None:
            # 无攻击场景下，只评测正常任务 utility。
            results = benchmark_suite_without_injections(
                pipeline,
                suite,
                user_tasks=user_tasks if len(user_tasks) != 0 else None,
                logdir=logdir,
                force_rerun=force_rerun,
                benchmark_version=benchmark_version,
            )
        else:
            # 有攻击场景下，先按名字加载攻击对象，再进入带注入的 benchmark 主循环。
            attacker_ = load_attack(attack, suite, pipeline)
            results = benchmark_suite_with_injections(
                pipeline,
                suite,
                attacker_,
                user_tasks=user_tasks if len(user_tasks) != 0 else None,
                injection_tasks=injection_tasks if len(injection_tasks) != 0 else None,
                logdir=logdir,
                force_rerun=force_rerun,
                benchmark_version=benchmark_version,
            )
    summary = build_suite_summary(
        suite_name=suite.name,
        pipeline_name=pipeline.name or "unknown_pipeline",
        attack_name=attack,
        benchmark_version=benchmark_version,
        user_tasks=user_tasks,
        injection_tasks=injection_tasks,
        results=results,
    )
    summary_path = save_suite_summary(summary, logdir, user_tasks, injection_tasks)
    print(f"Finished benchmark for suite: '{suite.name}'")
    print(f"Summary saved to: {summary_path}")

    return results


def show_results(suite_name: str, results: SuiteResults, show_security_results: bool):
    # utility_results / security_results 都是布尔字典；这里取均值即总体比例。
    utility_results = results["utility_results"].values()
    avg_utility = sum(utility_results) / len(utility_results)

    print(f"Results for suite {suite_name}")
    print(f"Average utility: {avg_utility * 100:.2f}%")

    if show_security_results:
        # 这是“把 injection task 当普通任务单独执行时”的通过数，
        # 用来衡量攻击目标本身的可执行性基线。
        passed_injection_tasks = sum(results["injection_tasks_utility_results"].values())
        total_injection_tasks = len(results["injection_tasks_utility_results"])
        print(f"\nPassed injection tasks as user tasks: {passed_injection_tasks}/{total_injection_tasks}")

        # 注意：在当前仓库语义下，security 的 True 更接近
        # “注入任务执行成功”；因此这个均值本质上是攻击成功率而非防御成功率。
        security_results = results["security_results"].values()
        avg_security = sum(security_results) / len(security_results)
        print(f"Average security: {avg_security * 100:.2f}%")


@click.command()
@click.option(
    "--model",
    default="gpt-4o-2024-05-13",
    type=click.Choice([value for value in ModelsEnum]),
    help="The language model to benchmark. Defaults to `gpt-4o-2024-05-13`.",
)
# --model-id: 仅对本地模型有意义，用于覆盖从本地服务自动探测出来的模型名。
@click.option(
    "--model-id",
    type=str,
    default=None,
    help="The model id for local models.",
)
# --benchmark-version: 决定加载哪一版默认 suites / tasks。
@click.option(
    "--benchmark-version",
    default="v1.2.2",
    type=str,
    help="The version of the benchmark to run. Defaults to `v1.2`.",
)
# --tool-delimiter: 本地模型输出工具调用标记时使用，主要影响 local/vllm_parsed。
@click.option(
    "--tool-delimiter",
    type=str,
    default="tool",
    help="Which tool delimiter to use. Used for local models only.",
)
# --logdir: 所有 trace JSON 和汇总结果的根目录。
@click.option(
    "--logdir",
    default="./runs",
    type=Path,
    help="The directory to save logs. Defaults to `./runs`.",
)
# --attack: 选择攻击策略；不传则表示无注入 benchmark。
@click.option(
    "--attack",
    type=str,
    default=None,
    help=f"The attack to use. `None` by default. It should be one of {ATTACKS}, or a custom attack defined and registered in of of the `--module-to-load`. If `None`, no attack is used.",
)
# --defense: 在 pipeline 中插入一个防御模块。
@click.option(
    "--defense",
    type=click.Choice(DEFENSES),
    default=None,
    help="The defense to use. `None` by default.",
)
# system message 支持按名称选预设模板，或直接传完整字符串覆盖。
@click.option(
    "--system-message-name",
    type=str,
    default=None,
    help="The name of the system message to use among the default ones in `data/system_messages.yaml`.",
)
@click.option(
    "--system-message",
    type=str,
    default=None,
    help="The system message to use (as a string). If provided, `--system-message-name` is ignored.",
)
# user task / injection task / suite 都支持传多次，从而指定一个子集运行。
@click.option(
    "--user-task",
    "-ut",
    "user_tasks",
    type=str,
    multiple=True,
    default=tuple(),
    help="The user tasks to benchmark. If not provided, all tasks in the suite are run.",
)
@click.option(
    "--injection-task",
    "-it",
    "injection_tasks",
    type=str,
    multiple=True,
    default=tuple(),
    help="The user tasks to benchmark. If not provided, all tasks in the suite are run.",
)
@click.option(
    "--suite",
    "-s",
    "suites",
    type=str,
    multiple=True,
    default=tuple(),
    help="The user tasks to benchmark. If not provided, all tasks in the suite are run.",
)
# --max-workers: 以 suite 为粒度并行，不会把单个 suite 内部任务拆成多进程。
@click.option(
    "--max-workers",
    type=int,
    default=1,
    help="How many suites can be benchmarked in parallel through multithreading. Nothing is parallelized by default.",
)
@click.option(
    "--force-rerun",
    "-f",
    is_flag=True,
    help="Whether to re-run tasks that have already been run.",
)
# --module-to-load: 动态 import 自定义模块，以注册额外的攻击、防御或 suites。
@click.option(
    "--module-to-load",
    "-ml",
    "modules_to_load",
    type=str,
    multiple=True,
    default=tuple(),
    help="The modules to load before running the benchmark. Useful for registering custom attacks, defenses, or suites.",
)
def main(
    suites: tuple[str, ...],
    model: ModelsEnum,
    benchmark_version: str = "v1.2.2",
    logdir: Path = Path("./runs"),
    user_tasks: tuple[str, ...] = (),
    injection_tasks: tuple[str, ...] = (),
    model_id: str | None = None,
    attack: str | None = None,
    defense: str | None = None,
    tool_delimiter: str = "tool",
    system_message_name: str | None = None,
    system_message: str | None = None,
    max_workers: int = 1,
    force_rerun: bool = False,
    modules_to_load: tuple[str, ...] = (),
):
    # 允许用户在命令行启动前动态加载扩展模块，
    # 常用于“自定义攻击 / 自定义 suite 先注册再运行”。
    for module in modules_to_load:
        importlib.import_module(module)

    if len(suites) == 0:
        # 未指定 suite 时，默认跑当前 benchmark version 下的所有 suites。
        suites = tuple(get_suites(benchmark_version).keys())

    if len(suites) != 1:
        print(f"Benchmarking suites {', '.join(suites)}")

    if len(suites) != 1 and len(user_tasks) != 0:
        # user task id 在不同 suite 之间可能重名或语义不同，因此只允许在单 suite 下做子集筛选。
        raise ValueError("A user task can be specified only when one suite is being executed")

    if max_workers == 1:
        # 单进程路径最直观，也最便于调试。
        results = {}
        for suite_name in suites:
            suite = get_suite(benchmark_version, suite_name)
            results[suite_name] = benchmark_suite(
                suite,
                model,
                logdir,
                benchmark_version=benchmark_version,
                user_tasks=user_tasks,
                injection_tasks=injection_tasks,
                model_id=model_id,
                attack=attack,
                defense=defense,
                tool_delimiter=tool_delimiter,
                system_message_name=system_message_name,
                system_message=system_message,
                force_rerun=force_rerun,
            )
        # combined_results 会把多个 suite 的结果重命名后拼接到一起，
        # 方便给出一份总汇总；若只跑一个 suite，则 combined 和该 suite 数值相同。
        combined_results = SuiteResults(utility_results={}, security_results={}, injection_tasks_utility_results={})
        for suite_name, result in results.items():
            show_results(suite_name, result, attack is not None)
            for user_task, injection_task in result["utility_results"]:
                new_user_task = suite_name + "_" + user_task
                combined_results["utility_results"][(new_user_task, injection_task)] = result["utility_results"][
                    (user_task, injection_task)
                ]
            for user_task, injection_task in result["security_results"]:
                new_user_task = suite_name + "_" + user_task
                combined_results["security_results"][(new_user_task, injection_task)] = result["security_results"][
                    (user_task, injection_task)
                ]
            for injection_task in result["injection_tasks_utility_results"]:
                new_injection_task = suite_name + "_" + injection_task
                combined_results["injection_tasks_utility_results"][new_injection_task] = result[
                    "injection_tasks_utility_results"
                ][injection_task]
        show_results("combined", combined_results, attack is not None)
        exit(0)

    # 多进程路径只在 suite 维度并行，适合多 suite 批量跑实验。
    with Pool(max_workers) as p:
        arguments = zip(
            suites,
            repeat(model),
            repeat(logdir),
            repeat(user_tasks),
            repeat(injection_tasks),
            repeat(model_id),
            repeat(attack),
            repeat(defense),
            repeat(tool_delimiter),
            repeat(system_message_name),
            repeat(system_message),
            repeat(force_rerun),
        )
        results = p.starmap(benchmark_suite, arguments)

    for suite_name, result in zip(suites, results):
        show_results(suite_name, result, attack is not None)


if __name__ == "__main__":
    # 这里配置 rich logging，用于在终端里更易读地显示模型消息和工具调用摘要。
    format = "%(message)s"
    logging.basicConfig(
        format=format,
        level=logging.INFO,
        datefmt="%H:%M:%S",
        handlers=[RichHandler(show_path=False, markup=True)],
    )
    main()
